package com.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

import org.springframework.stereotype.Component;
import org.springframework.stereotype.Repository;

import com.pojo.BankAccount;

@Component
public class BankAccountepositoryImpl implements BankAccountRepository {

	private static Connection conn;

	@Override
	public double getBalance(long accountId) {

		String query = "select accountbalance from bankaccount where accountid=?";
		double balance = -1;
		try {
			conn = getConnection();
			PreparedStatement ps = conn.prepareStatement(query);
			ps.setLong(1, accountId);
			ResultSet rs = ps.executeQuery();
			while (rs.next()) {
				balance = rs.getLong("accountbalance");

			}

		} catch (Exception e) {
			e.printStackTrace();

		}

		//return balance;

		
		  ArrayList<BankAccount> data=getData();
		  for(BankAccount ba:data) {
		  if(ba.getAccountId()==accountId) { return ba.getAccountBalance(); }
		  
		  } return -1;
		 

	}

	@Override
	public double updateBalance(long accountId, double newBalance) {

		String query = "update bankaccount set accountbalance=? where accountid=?";
		int updatedRows = -1;
		double balance = -1;
		try {
			conn = getConnection();
			PreparedStatement ps = conn.prepareStatement(query);
			ps.setDouble(1, newBalance);
			ps.setLong(2, accountId);
			updatedRows = ps.executeUpdate();

		} catch (Exception e) {
			e.printStackTrace();

		}

		if (updatedRows == 1) {
			return newBalance;

		} 
		else {
			return -1;
		}
	}

	public Connection getConnection() throws Exception {

		Class.forName("oracle.jdbc.driver.OracleDriver");
		conn = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe", "system", "orcl11g");

		return conn;

	}

	public ArrayList<BankAccount> getData() {
		ArrayList<BankAccount> list = new ArrayList<>();
		list.add(new BankAccount(100, "pavan", "savings", 2000));
		list.add(new BankAccount(101, "kalyan", "savings", 5000));

		return list;

	}

}
