package com.pojo;

import org.springframework.beans.factory.annotation.Autowired;

import com.service.*;

public class BankAccountController {
	
	@Autowired
	private BankAccountServiceImpl bankAccountServiceImpl;
	
	public double withdraw(long accountId, double balance) {
		return bankAccountServiceImpl.withdraw(accountId, balance);
		
		
	}
	public double deposit(long accountId, double balance) {
		return bankAccountServiceImpl.deposit(accountId, balance);
		
	}
	public void setService(BankAccountServiceImpl service) {
		this.bankAccountServiceImpl = service;
	}
	public double getBalance(long accountId) {
		return bankAccountServiceImpl.getBalance(accountId);
		
	}
	public boolean fundTransfer(long fromAccount, long toAccount, double amont) {
		return bankAccountServiceImpl.fundTransfer(fromAccount, toAccount, amont);
		
	}

}
