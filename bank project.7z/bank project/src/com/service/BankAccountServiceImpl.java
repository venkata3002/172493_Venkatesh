package com.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import com.dao.*;

@Component
public class BankAccountServiceImpl implements BankAccountService {
	
	
	@Autowired
	private BankAccountepositoryImpl bankAccountepositoryImpl;

	@Override
	public double withdraw(long accountId, double balance) {
		double availableBalance=bankAccountepositoryImpl.getBalance(accountId);
		if(availableBalance>=balance) {
			return bankAccountepositoryImpl.updateBalance(accountId, availableBalance-balance);
		}
		else {
			return -1;
		}
		
	}

	public void setRepository(BankAccountepositoryImpl repository) {
		this.bankAccountepositoryImpl = repository;
	}

	@Override
	public double deposit(long accountId, double balance) {
		double availableBalance=bankAccountepositoryImpl.getBalance(accountId);
		
		return bankAccountepositoryImpl.updateBalance(accountId, availableBalance+balance);
	}

	@Override
	public double getBalance(long accountId) {
		return bankAccountepositoryImpl.getBalance(accountId);
	}

	@Override
	public boolean fundTransfer(long fromAccount, long toAccount, double amount) {
		double availableBalance=bankAccountepositoryImpl.getBalance(fromAccount);
		if(availableBalance>=amount) {
			double availableBalanceInToAccount=bankAccountepositoryImpl.getBalance(toAccount);
			bankAccountepositoryImpl.updateBalance(toAccount,availableBalanceInToAccount+amount);
			bankAccountepositoryImpl.updateBalance(fromAccount,availableBalance-amount);
			return true;
			
			
			
		}
		
		return false;
	}
	

}
