package com.test;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.model.Employee;
import com.model.Student;

public class Test {

	public static void main(String[] args) {
		ApplicationContext context=new ClassPathXmlApplicationContext("Spring.xml");
		Student s=(Student)context.getBean("StudentBean");
		Employee e=(Employee)context.getBean("EmployeeBean");
		
	System.out.println("Employee details");
	System.out.println("-------------------------------------");
		System.out.println(e.getName()+"\n");
		System.out.println(e.getId());
		System.out.println("Student details");
		System.out.println("-------------------------------------");
		
		System.out.println(s.getName()+"\n");
		System.out.println(s.getId());
		
		s.setName("dummy name");
	

	}

}
