package com.aspect;


import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;

@Aspect
public class StudentAspect {
	
	@Before("execution(* get*(..))")
	public void welcome(JoinPoint joinpoint) {
		System.out.println(joinpoint.toString());
		System.out.println(joinpoint.getTarget());
		
	}
	
	
	
	@Before("args(name)")
	public void mm(String name) {
		System.out.println("in aspect the value is"+name);
		
	}
		
	

}
