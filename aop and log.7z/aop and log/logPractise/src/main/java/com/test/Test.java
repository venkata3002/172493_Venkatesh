package com.test;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class Test {
	private final Logger log=LoggerFactory.getLogger(Test.class);
	private final Logger log1=LoggerFactory.getLogger(Test.class);

	public static void main(String[] args) {
	Test t=new Test();
	t.ss();
		
		
		

	}
	
	public void ss() {
		log.debug("hiiiii this is debug");
		log.info("hello this is info");
		log.error("this is error");
	}

}
