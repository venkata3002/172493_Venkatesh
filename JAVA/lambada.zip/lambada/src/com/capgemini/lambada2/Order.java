package com.capgemini.lambada2;


	public interface Order {

		String orderstatus(double Orderprice,String OrdersStatus);
	}

