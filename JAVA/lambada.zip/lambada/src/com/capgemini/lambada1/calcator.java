package com.capgemini.lambada1;
@FunctionalInterface
public interface calcator {
	 int operation(int a, int b);
}
