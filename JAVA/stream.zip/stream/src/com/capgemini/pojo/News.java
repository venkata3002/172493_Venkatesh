package pojo;

public class News {
	int newsId;
	String postedByUser;
	String commentByUser;
	String comment;
	
	

}
