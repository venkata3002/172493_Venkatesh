package com.cg.springrest.SpringRest;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class StudentDb {
	private long id; 
	private String profilename;
	private String firstname;
	private String lastname;
	private String created;
	@Override
	public String toString() {
		return "StudentDb [id=" + id + ", profilename=" + profilename + ", firstname=" + firstname + ", lastname="
				+ lastname + ", created=" + created + "]";
	}
	public StudentDb() {
		super();
		// TODO Auto-generated constructor stub
	}
	public StudentDb(long id, String profilename, String firstname, String lastname) {
		super();
		this.id = id;
		this.profilename = profilename;
		this.firstname = firstname;
		this.lastname = lastname;
		
	}
	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public String getProfilename() {
		return profilename;
	}
	public void setProfilename(String profilename) {
		this.profilename = profilename;
	}
	public String getFirstname() {
		return firstname;
	}
	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}
	public String getLastname() {
		return lastname;
	}
	public void setLastname(String lastname) {
		this.lastname = lastname;
	}
	public String getCreated() {
		return created;
	}
	public void setCreated(String created) {
		this.created = created;
	}
}
