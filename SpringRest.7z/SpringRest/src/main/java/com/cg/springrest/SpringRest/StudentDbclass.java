package com.cg.springrest.SpringRest;

import java.util.HashMap;
import java.util.Map;

public class StudentDbclass {
	private static Map<Long,Message1> m1= new HashMap<>();
	private static Map<Long,StudentDb> m2= new HashMap<>();

	public static Map<Long,Message1> getMessage(){
		return m1;
		
	}
	
	public static Map<Long,StudentDb> getProfile(){
		return m2;
		
	}
}
