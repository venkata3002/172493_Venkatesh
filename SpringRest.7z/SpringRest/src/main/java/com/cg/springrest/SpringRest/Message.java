package com.cg.springrest.SpringRest;

import java.util.List;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

@Path("/welcome")
public class Message {
	
	MessageService m1= new MessageService();
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	public List<Message1> getMessage()
	{
		return m1.getAllMessages();
	}
	
	@POST
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	public Message1 addmessage(Message1 message) {
		return m1.addmessage(message);
		
	}
	
	
	@PUT
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	public Message1 updateMessage(Message1 message) {
		return m1.updateMessage(message);
	}
	
	@GET
	@Path("/{anymessage}")
	@Produces(MediaType.APPLICATION_JSON)
	public Message1 test(@PathParam("anymessage") long Id) {
		return m1.getmessage(Id);		
	}
}
