package com.cg.springrest.SpringRest;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class MessageService {
	
	private	 Map<Long,Message1> m1=StudentDbclass.getMessage();
	
	
	public  List<Message1> getAllMessages(){
		
		return new ArrayList<Message1>( m1.values());
		
	}
	
	
	
	
	
	
	
	public MessageService() {
		m1.put(1L, new Message1(1,"Helloworld","Mahesh"));
		m1.put(2L, new Message1(1,"hello bro","Manu"));
	}







	public Message1 getmessage(long id) {
		return m1.get(id);
		
	}
 public Message1 addmessage(Message1 message) {
	 message.setId(m1.size()+1);
	 m1.put(message.getId(), message);
	 return message;
 }
 
 public Message1 updateMessage(Message1 message) {
	 if(message.getId()<=0) {
		 return null;
	 }
	 m1.put(message.getId(), message);
	 return message;
 }
  public Message1 removeMessage(long id) {
	  return m1.remove(id);
	  
  }
 
 
 

}
